<?php
require_once('my-route/calendar.php');
require_once('my-route/front.php');
require_once('my-route/backend.php');

require __DIR__.'/auth.php';